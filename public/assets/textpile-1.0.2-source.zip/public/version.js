// Textpile version - Single source of truth
// Update this file when releasing a new version
export const TEXTPILE_VERSION = "1.0.2";
